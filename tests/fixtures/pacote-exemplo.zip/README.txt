AI STUDIO — COMUNICAÇÃO CONTÁBIL · PACOTE DE PUBLICAÇÃO

Título: Atualização do Sistema IFRS 16
Categoria: Divulgação de Sistemas
Destino previsto: Central de Conteúdo → Newsletter (Tecnologia)
Categoria no portal: Tecnologia
Versão aprovada: v4 (33333333-3333-4333-8333-333333333333)
Aprovada em: 2026-09-22T18:00:00.000Z
Substitui: nenhuma publicação anterior

COMO IMPORTAR
1. Portal da Gerência de Contabilidade → Administração → aba "Importar do AI Studio".
2. Selecione este arquivo .zip (não extraia).
3. Confira a validação de integridade (SHA-256) e de origem (assinatura).
4. Revise a pré-visualização e confirme a importação.
5. O conteúdo entra como "Em revisão" no Painel Editorial; a publicação exige a aprovação final no portal.
6. Após publicar, registre a confirmação na Central de Publicações do AI Studio.

ARQUIVOS
- manifest.json: dados estruturados da versão aprovada.
- atualizacao-do-sistema-ifrs-16-v4.png: peça visual (640×360).
- checksums.sha256: hashes SHA-256 do manifesto e da imagem.
- manifest.sig: assinatura ECDSA P-256 (SHA-256) do manifest.json.

O hash comprova integridade; a assinatura comprova a origem. Nenhum dos dois substitui a revisão final no portal.
